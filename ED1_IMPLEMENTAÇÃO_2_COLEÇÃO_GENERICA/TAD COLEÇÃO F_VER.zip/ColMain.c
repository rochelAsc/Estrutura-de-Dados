#include "colecao.h"

void processarDisco(void* item) {
    Disco* disco = (Disco*)item;
    printf("Nome: %s, Ano: %d, N de Serie: %f\n", disco->nome, disco->ano, disco->numSerie);
}

int main(void){
  printf("Insira um tamanho pra sua colecao: ");
  int n; int i = 0; int ano; float numSerie;
  scanf("%d",&n);
        Cofo* colecao = GcofCreate(n);
    if (colecao == NULL)
    {
        return FALSE;
    }
  printf("Colecao criada com sucesso!\n"
         "Agora, insira tres elementos na colecao!\n");

        while (i < 3)
        {
            Disco* disco = (Disco*)malloc(sizeof(Disco));
            if (i < n)
            {
                printf("Digite um ano de fabricacao que esteja entre 1948 e 2025:" );
                if(scanf("%d",&ano) != TRUE ||ano < 1948 || ano > 2025)
                {
                    return FALSE;
                }
                printf("\n");
                printf("Digite o numero de fabricacao, que deve ser maior que zero:");
                if (scanf("%f", &numSerie) != TRUE || numSerie < 1)
                {
                    return FALSE;
                }
                printf("\n");
                printf("Digite o nome do seu disco:");
                scanf("%s", disco->nome);
                disco->ano = ano;
                disco->numSerie = numSerie;
                GcofInsert(colecao, disco);
                i++;
            }
            else
            {
                printf("Seu cofo ficou cheio");
                return FALSE;
            }
        }

   printf("Seus discos foram registrados! Veja-os..\n");
    gCofShow(colecao, processarDisco);

printf("\n");
    printf("Consulte um elemento dentro do cofo\n");

    Disco chave = {0};
    printf("Digite o ano do disco a ser buscado:");
    scanf("%d", &chave.ano);
    printf("\n");
    printf("Digite o numero de serie do disco a ser buscado:");
    scanf("%f", &chave.numSerie);
    printf("\n");
    printf("Digite o nome do disco a ser buscado:");
    scanf("%29s", chave.nome);
    printf("\n");
  Disco* resultado = (Disco*)GcofQuery(colecao, &chave, compararDisco);
  if (resultado != NULL)
      {
      printf("Disco encontrado!\n");
      printf("Ano: %d, Numero de Serie: %f, Nome: %s\n",
      resultado->ano, resultado->numSerie, resultado->nome);
      }
    else
        {
        printf("Disco nao encontrado.\n");
        }
    printf("Ops..parece que o segundo elemento no seu cofo foi afetado pela lei de direitos autorais!\n");

    GcofRemovePos(colecao, 1);
    printf("Seu segundo disco foi removido!\n");

    printf("Os discos restantes sao:\n");
    gCofShow(colecao, processarDisco);

    printf("Esvaziamos sua colecao!\n");
    GcofEmpty(colecao);

    printf("Os discos restantes sao:\n");
    gCofShow(colecao, processarDisco);
    printf("Parece que nao ha discos restando..\n");
    GcofDestroy(colecao);

    system("pause");
  return TRUE;
}