#include "matrix.h"

int main(void)
{
    int n, m, i, j;
    float k;
    Matrix* mat;

    printf("Digite o número de linhas da matriz: ");
    scanf("%d", &n);
    printf("Digite o número de colunas da matriz: ");
    scanf("%d", &m);

    mat = matCreate(n, m); // Armazena o ponteiro retornado
    if (mat == NULL) {
        printf("Erro ao criar a matriz.\n");
        return 1; // Finaliza o programa em caso de erro
    }

    printf("Matriz criada com sucesso (%d linhas, %d colunas).\n", matGetNumLines(mat), matGetNumCollumns(mat));

    printf("Escolha em qual linha você quer colocar seu numero: ");
    scanf("%d", &i);
    printf("Escolha em qual coluna você quer colocar seu numero: ");
    scanf("%d", &j);
    printf("Digite o numero: (lembre-se, seu número deve ser um numero real separado por . senão o programa se encerrará)");
    scanf("%f", &k);
    if (i < 0 || i >= mat->linha || j < 0 || j >= mat->coluna){
    	printf("Erro, parametros não-validos");
    	return 1;
    }
    matSetElemIJ(mat, i, j, k);
    printf("Elemento na posição (%d, %d): %f\n", i, j, matGetElemIJ(mat, i, j));

    int flag = FALSE;
    printf("Deseja destruir sua matriz? Se sim, digite 1:\n");
    scanf("%d", &flag);
    if (flag){
    	//matDestroy(mat);
		if (matDestroy(mat)) {
        	printf("Matriz destruída com sucesso.\n");
        }
        else {
        	printf("Erro ao destruir a matriz.\n");
    	}    	
    }
system("pause");
    return 0; // Indica que o programa terminou corretamente
}