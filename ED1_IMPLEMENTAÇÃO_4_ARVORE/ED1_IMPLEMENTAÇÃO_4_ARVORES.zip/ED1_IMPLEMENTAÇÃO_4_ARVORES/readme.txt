readme.txt

Este programa implementa um TAD para manipulação de uma lista simplesmente encadeada.
Propriedade de: ROCHEL ANDREY DOS SANTOS COSTA
MATRICULA: 2023090100

1 Ambiente ao qual o programa foi desenvolvido:
- SO: Windows 11
- Compilador: MinGW, GCC
- Linguagem: C
- IDE: CLion e Prompt de Comando

2 Arquivos
- Tree.h: define os protótipos e os cabeçalhos que vão ser utilizados no arquivo de implementação
- TREE.c: Implementação das funções
- main.c: Arquivo principal, função main com todo o programa utilizando as funções descritas no enunciado
- main.exe: Arquivo executável gerado após a compilação do código.

 Formas de executar:

Executando o arquivo utilizando a IDE (preferencialmente CLion) utilizando a forma genérica de execução
Clique duplo no arquivo executável main, disponível na pasta em que se encontra esse readme

OBS: Caracteres como "ã" ou "~~" "´´" não são mostrados corretamente (usualmente) por causa da formatação de caracteres 
