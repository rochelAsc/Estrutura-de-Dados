#include <stdio.h>
#include <stdlib.h>
#include "Tree.h"
#define TRUE 1
#define FALSE 0

void listaElementos(TNode *t,int *i) {
    if(t!=NULL && t->data!=NULL) {
        listaElementos(t->l,i);
        elemento *data = (elemento*)t->data;
        printf("\n%d° Item:\n%s%d\n%.2f\n\n", *i, data->nome, data->num, data->valor);
        (*i)++;
        listaElementos(t->r,i);
    }
}


int cmpint(void *elm1, void *elm2) {
    int *key = (int *)elm1;
    elemento *pelm2 = (elemento *)elm2; 

    if (pelm2->num < *key) {
        return -1;
    } else if (pelm2->num > *key) {
        return 1;
    } else {
        return 0;
    }
}

int cmpfloat( void * elm1, void * elm2) {
	float *pelm1, *pelm2;
	pelm1 = (float *) elm1;
	pelm2 = (float *) elm2;
	if (*pelm1 < *pelm2) {
		return -1;
	} else if (*pelm1 > *pelm2) {
		return 1;
	} else {
		return 0;
	}
}

int cmpchar( void * elm1, void * elm2) {
	char *pelm1, *pelm2;
	pelm1 = (char *) elm1;
	pelm2 = (char *) elm2;

	while(*pelm1 != '\0'&&*pelm2 !='\0') {
		if(*pelm1 != *pelm2) {
			return -1;
		}
		pelm1++;
		pelm2++;
	}
	return 0;
}

int main() {

    elemento *item = malloc(sizeof(elemento));
	Tree *tree = NULL;
    /*
	if (tree == NULL) {
		printf("Erro ao alocar memC3ria.\n");
		exit(1);  
	}
	tree->raiz = NULL;
	*/

	printf("Bem-vindo! Escolha uma das opcoes abaixo:\n\n");
	printf("1 - Criar uma colecao\n");
	printf("2 - Inserir na colecao\n");
	printf("3 - Remover um elemento da colecao\n");
	printf("4 - Destruir colecao\n");
	printf("5 - Listar elementos da colecao\n");
	printf("6 - Consultar elemento\n");
	printf("0 - Sair do menu\n");

	int escolha;


	while (1) {
		scanf("%d", &escolha);

		if (escolha == 0) {
			break;
		}

		if (escolha == 1) {
			if (tree == NULL) {
				tree = abpCreate();
				if(tree!=NULL){
				    printf("Colecao criada!\n");
				}else {
				    printf("A colecao nao foi criada.\n");
				}
			}    
			else{
			    printf("Colecao ja criada!\n");
			}
		}

		if (escolha == 2) {
			if (tree == NULL) {
				printf("Primeiro crie a colecao!\n");
			} else {
			    item = malloc(sizeof(elemento));
                if (item == NULL) {
                    printf("Erro ao alocar memória!\n");
                    exit(1);
                }
			    
				printf("Digite o nome desejado: \n");
				getchar();
				fgets(item->nome, 30, stdin);

				printf("Digite o numero desejado: \n");
				scanf("%d", &item->num);

				printf("Digite o valor: \n");
				scanf("%f", &item->valor);

				tree->raiz = abpInsert(tree->raiz, item, cmpint);

				if (tree != NULL) {
					printf("Elemento adicionado com sucesso!\n");
				} else {
					printf("Erro ao adicionar.\n");
				}
			}
		}

		if (escolha == 3) {
			int numeroDado;
			printf("Digite o numero desejado: ");
			scanf("%d", &numeroDado);
			void *valorRemovido = NULL;
			tree->raiz = abpRemove(tree->raiz, &numeroDado, cmpint, &valorRemovido);
			if (valorRemovido != NULL) {
                printf("Elemento de numero %d removido!\n", ((elemento *)valorRemovido)->num);
                free(valorRemovido); 
            } else{
                printf("Elemento não encontrado.\n");
            }
		}
				
		

		if (escolha == 4){
			int checagem = abpDestroy(tree);
			if(checagem==TRUE){
			    printf("Colecao destruida!\n");
			}else{
			    printf("\nColecao nao destruida!\n");
			}
			
		}
		if(escolha == 5) {
		    
		    int i = 1;
		    if(tree == NULL || tree->raiz==NULL){
		        printf("Colecao vazia! Nao ha o que listar.");
		    }else{
		        listaElementos(tree->raiz,&i);
		    }
		}
		if(escolha == 6) {
			int numeroIndicado;
			printf("Digite o numero a ser consultado: ");
			scanf("%d",&numeroIndicado);
			elemento *valor = (elemento *)abpQuery(tree->raiz, &numeroIndicado, cmpint);
			if(valor==NULL){
			    printf("Elemento nao encontrado:\n");
			}else{
			    printf("\nvalor pedido: %d\n\n", valor->num);
			    printf("Elemento de numero %d\nNome: %svalor: %2.f\nEncontrado!\n", valor->num,valor->nome,valor->valor);
			}
		}

		printf("\nEscolha uma das opcoes abaixo:\n\n");
		printf("1 - Criar uma colecao\n");
		printf("2 - Inserir na colecao\n");
		printf("3 - Remover um elemento da colecao\n");
		printf("4 - Destruir colecao\n");
		printf("5 - Listar elementos\n");
		printf("6 - Consultar elemento\n");
		printf("0 - Sair do menu\n");
	}

	return 0;

}