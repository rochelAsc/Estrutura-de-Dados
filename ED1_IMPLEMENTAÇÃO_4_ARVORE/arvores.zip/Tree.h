#ifndef TREE_H
#define TREE_H

#include <stdio.h>
#include <stdlib.h>

#define TRUE 1
#define FALSE 0

typedef struct{
    char nome[30];
    float valor;
    int num;
}elemento;

typedef struct _tnode_ {
  void *data;
  struct _tnode_ *l;  
  struct _tnode_ *r;
}TNode;

typedef struct _tree_ {
  TNode *raiz;
}Tree;
  
typedef struct _tnode_ TNode;
typedef struct _tree_ Tree;

void *abpQuery( TNode *t, void *key, int (*cmp)(void *, void *));
Tree *abpCreate();
int abpDestroy( Tree *t);
TNode *abpInsert( TNode *t, void *data, int (*cmp)(void *, void *));
TNode *abpRemoveMaior( TNode *t, int (*cmp)(void *, void *), void **data);
TNode *abpRemove( TNode *t, void *key, int (*cmp)(void *, void *), void **data);

#endif