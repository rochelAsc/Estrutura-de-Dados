#include <stdio.h>
#include <stdlib.h>
#include "Tree.h"


void *abpQuery(TNode *t, void *key, int (*cmp)(void *, void *)){
  int stat;
  if (t != NULL) {
    stat = cmp(key, t->data);
    if (stat == 0) {
      return t->data;
    } 
    else {
      if (stat == -1) {
        return abpQuery(t->l, key, cmp);
      } 
      else {
        return abpQuery(t->r, key, cmp);
      }
    
    }
  }
  return NULL;
}

Tree *abpCreate(){
  Tree *t ;
  t = (Tree *) malloc(sizeof(Tree)); 
  if(t != NULL){
    t->raiz = NULL;
    return t;
  }
  return NULL;
}

int EsvaziaTree(TNode *t){
    if(t!=NULL){
        EsvaziaTree(t->l);
		EsvaziaTree(t->r);
		if(t->data!=NULL){
		    free(t->data);
		}
		free(t);
		    
    }
    return TRUE;
}

int abpDestroy ( Tree *t){
    if ( t != NULL ) {
        if ( t->raiz == NULL ) {
            free (t);
            return TRUE;
        }
        else{
            EsvaziaTree(t->raiz);
            t->raiz = NULL;
            free(t);
            t = NULL;
            return TRUE;
        }
    }
    return FALSE;
}

TNode *abpInsert( TNode *t, void *data, int (*cmp)(void *, void *)){
  TNode *newnode;
  int stat;
  if (t != NULL ) {
    stat = cmp(data, t->data);
    if (stat <=0){
      t->l = abpInsert(t->l, data, cmp);
    }else{
      t->r = abpInsert(t->r, data, cmp);
    } 
    return t;
  }else{
    newnode = (TNode *)malloc( sizeof(TNode));
    if ( newnode != NULL ) {
      newnode->data = data;
      newnode->l = NULL;
      newnode->r= NULL;
      return newnode;
    }else{
      return NULL;
    }
  }   
}

TNode *abpRemove( TNode *t, void *key, int (*cmp)(void *, void *), void **data){ 
  void *data2; int stat; void *aux;
  if ( t != NULL ){
    stat = cmp(key, t->data);
    if(stat < 0 ){
      t->l = abpRemove(t->l, key, cmp, data);
      return t;
    }else if ( stat > 0 ) {
      t->r = abpRemove(t->r, key, cmp, data );
      return t;
    }else {
        *data = t->data;
        if (t->l == NULL && t->r == NULL) {
            free(t);
            return NULL;
        }else if (t->l == NULL ) {
            aux = t->r; 
            free(t);
            return aux;
        }else if ( t->r == NULL ) {
            aux = t->l; 
            free(t);
            return aux;
        }else {
            *data = t->data;
            t->l = abpRemoveMaior(t->l, cmp, &data2);
            t->data = data2;
            return t;
        }
    }
  }
  *data = NULL;
  return NULL;
}

TNode *abpRemoveMaior( TNode *t, int (*cmp)(void *, void *), void **data){ 
  void *data2, *aux;
  if ( t != NULL ) {
    if ( t->r != NULL ) {
      t->r = abpRemoveMaior(t->r, cmp, &data2);
    } 
    else {
      if (t->l != NULL ) {
        aux = t->l; 
        *data = t->data;
        free(t);
        return aux;
      }
      else{
      *data = t->data;
      free(t);
      return NULL;
      }
    }
  }
  *data = NULL;
  return NULL;
}
